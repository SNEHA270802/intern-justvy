from django.db import models
from django.utils.timezone import now
from django.contrib.auth import get_user_model

User = get_user_model()

class BaseModel(models.Model):
    """
    Abstract base model with common fields for tracking creation, updates, and soft deletion.
    """
    created_at = models.DateTimeField(default=now, editable=False)
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='%(class)s_created',
        editable=False
    )
    updated_at = models.DateTimeField(null=True, blank=True, editable=False)
    updated_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='%(class)s_updated',
        editable=False
    )
    deleted_at = models.DateTimeField(null=True, blank=True, editable=False)
    deleted_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='%(class)s_deleted',
        editable=False
    )
    delete_status = models.BooleanField(default=False, editable=False)

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        """Override save to automatically set created_by/updated_by fields"""
        user = kwargs.pop('user', None)
        
        if not self.pk:  # New instance
            if user and user.is_authenticated:
                self.created_by = user
        else:  # Updating existing instance
            self.updated_at = now()
            if user and user.is_authenticated:
                self.updated_by = user
        
        super().save(*args, **kwargs)

    def delete(self, user=None, *args, **kwargs):
        """Soft delete implementation"""
        self.delete_status = True
        self.deleted_at = now()
        if user and user.is_authenticated:
            self.deleted_by = user
        self.save(user=user)

class Author(BaseModel):
    """
    Model representing an author of books.
    """
    name = models.CharField(max_length=255)
    email = models.EmailField(unique=True)

    class Meta:
        ordering = ['name']
        verbose_name = 'Author'
        verbose_name_plural = 'Authors'

    def __str__(self):
        return self.name

class Book(BaseModel):
    """
    Model representing a book in the bookstore.
    """
    title = models.CharField(max_length=255)
    description = models.TextField()
    published_date = models.DateField()
    author = models.ForeignKey(
        Author,
        on_delete=models.CASCADE,
        related_name='books'
    )

    class Meta:
        ordering = ['-published_date', 'title']
        verbose_name = 'Book'
        verbose_name_plural = 'Books'
        indexes = [
            models.Index(fields=['title']),
            models.Index(fields=['published_date']),
        ]

    def __str__(self):
        return self.title
