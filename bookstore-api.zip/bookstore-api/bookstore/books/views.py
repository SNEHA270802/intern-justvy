from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.utils.timezone import now
from .models import Author, Book
from .serializers import AuthorSerializer, BookSerializer

class AuthorListCreateView(APIView):
    def get(self, request):
        authors = Author.objects.filter(delete_status=False)
        serializer = AuthorSerializer(authors, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = AuthorSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(created_by=request.user.username)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class AuthorRetrieveUpdateDeleteView(APIView):
    def get_object(self, pk):
        try:
            return Author.objects.get(pk=pk, delete_status=False)
        except Author.DoesNotExist:
            return None

    def get(self, request, pk):
        author = self.get_object(pk)
        if not author:
            return Response(status=status.HTTP_404_NOT_FOUND)
        serializer = AuthorSerializer(author)
        return Response(serializer.data)

    def put(self, request, pk):
        author = self.get_object(pk)
        if not author:
            return Response(status=status.HTTP_404_NOT_FOUND)
        serializer = AuthorSerializer(author, data=request.data)
        if serializer.is_valid():
            serializer.save(updated_by=request.user.username, updated_at=now())
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        author = self.get_object(pk)
        if not author:
            return Response(status=status.HTTP_404_NOT_FOUND)
        author.delete_status = True
        author.deleted_by = request.user.username
        author.deleted_at = now()
        author.save()
        return Response(status=status.HTTP_204_NO_CONTENT)

# Similar views for Book model
class BookListCreateView(APIView):
    def get(self, request):
        books = Book.objects.filter(delete_status=False)
        serializer = BookSerializer(books, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = BookSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(created_by=request.user.username)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class BookRetrieveUpdateDeleteView(APIView):
    def get_object(self, pk):
        try:
            return Book.objects.get(pk=pk, delete_status=False)
        except Book.DoesNotExist:
            return None

    def get(self, request, pk):
        book = self.get_object(pk)
        if not book:
            return Response(status=status.HTTP_404_NOT_FOUND)
        serializer = BookSerializer(book)
        return Response(serializer.data)

    def put(self, request, pk):
        book = self.get_object(pk)
        if not book:
            return Response(status=status.HTTP_404_NOT_FOUND)
        serializer = BookSerializer(book, data=request.data)
        if serializer.is_valid():
            serializer.save(updated_by=request.user.username, updated_at=now())
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        book = self.get_object(pk)
        if not book:
            return Response(status=status.HTTP_404_NOT_FOUND)
        book.delete_status = True
        book.deleted_by = request.user.username
        book.deleted_at = now()
        book.save()
        return Response(status=status.HTTP_204_NO_CONTENT)