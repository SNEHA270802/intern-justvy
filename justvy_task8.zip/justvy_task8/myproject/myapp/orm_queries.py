
import os
import django

# Set up Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'myproject.settings')
django.setup()

from myapp.models import Customer, Order
from datetime import datetime, timedelta

def print_separator(title):
    print(f"\n{'='*50}")
    print(f"{' '*10}{title}")
    print(f"{'='*50}\n")

def run_orm_queries():
    
    # Task 2.1: Create a new customer
   
    print_separator("Creating Customers")
    
    customer1 = Customer.objects.create(
        name="John Doe",
        email="john@example.com"
    )
    print(f"Created customer: {customer1}")
    
    customer2 = Customer.objects.create(
        name="Jane Smith",
        email="jane@example.com"
    )
    print(f"Created customer: {customer2}")

   
    # Task 2.2: Create orders linked to customers
    
    print_separator("Creating Orders")
    
    order1 = Order.objects.create(
        customer=customer1,
        product_name="Laptop",
        price=999.99
    )
    print(f"Created order: {order1}")
    
    order2 = Order.objects.create(
        customer=customer1,
        product_name="Mouse",
        price=25.50
    )
    print(f"Created order: {order2}")
    
    order3 = Order.objects.create(
        customer=customer2,
        product_name="Keyboard",
        price=75.00
    )
    print(f"Created order: {order3}")

   
    # Task 2.3: Retrieve all orders for a specific customer

    print_separator("Retrieving Orders for John Doe")
    
    # Method 1: Using related_name (defined in model as 'orders')
    johns_orders = customer1.orders.all()
    print("John's orders (using related_name):")
    for order in johns_orders:
        print(f"- {order.product_name} (${order.price})")
    
    # Method 2: Using filter()
    janes_orders = Order.objects.filter(customer=customer2)
    print("\nJane's orders (using filter()):")
    for order in janes_orders:
        print(f"- {order.product_name} (${order.price})")

   
    # Task 2.4: Update a customer's email
    
    print_separator("Updating Customer Email")
    
    print(f"Original email for John: {customer1.email}")
    customer1.email = "john.doe@newdomain.com"
    customer1.save()
    print(f"Updated email for John: {customer1.email}")

    
    # Task 2.5: Delete an order
   
    print_separator("Deleting an Order")
    
    print(f"Total orders before deletion: {Order.objects.count()}")
    order2.delete()
    print(f"Total orders after deletion: {Order.objects.count()}")

 
if __name__ == "__main__":
    run_orm_queries()