from django.contrib import admin
from .models import Customer, Order

class CustomerAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'created_at')
    search_fields = ('name',)
    readonly_fields = ('created_at',)

class OrderAdmin(admin.ModelAdmin):
    list_display = ('customer', 'product_name', 'amount', 'order_date')
    list_filter = ('order_date',)
    readonly_fields = ('order_date',)

admin.site.register(Customer, CustomerAdmin)
admin.site.register(Order, OrderAdmin)

from django.contrib import admin
from .models import CustomerInquiry

class CustomerInquiryAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'submitted_at')
    search_fields = ('name', 'email')
    readonly_fields = ('submitted_at',)
    list_filter = ('submitted_at',)

admin.site.register(CustomerInquiry, CustomerInquiryAdmin)