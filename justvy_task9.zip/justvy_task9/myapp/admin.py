from django.contrib import admin
from .models import Customer, Order

class CustomerAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'created_at')
    search_fields = ('name',)
    readonly_fields = ('created_at',)

class OrderAdmin(admin.ModelAdmin):
    list_display = ('customer', 'product_name', 'amount', 'order_date')
    list_filter = ('order_date',)
    readonly_fields = ('order_date',)

admin.site.register(Customer, CustomerAdmin)
admin.site.register(Order, OrderAdmin)
