from django import forms
from django.core.exceptions import ValidationError
from .models import CustomerInquiry
import re

class CustomerForm(forms.ModelForm):
    message = forms.CharField(widget=forms.Textarea(attrs={'rows': 4}))
    
    class Meta:
        model = CustomerInquiry
        fields = ['name', 'email', 'message']
    
    def clean_name(self):
        name = self.cleaned_data['name']
        if not re.match(r'^[a-zA-Z\s]+$', name):
            raise ValidationError("Name should contain only alphabets and spaces.")
        return name
    
    def clean_email(self):
        email = self.cleaned_data['email']
        if CustomerInquiry.objects.filter(email=email).exists():
            raise ValidationError("This email has already been used for an inquiry.")
        return email