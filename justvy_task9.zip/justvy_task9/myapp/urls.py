from django.urls import path
from .views import inquiry_view

urlpatterns = [
    path('inquiry/', inquiry_view, name='inquiry'),
]